# ShopPilot ERP

A static, GitHub Pages-ready frontend prototype for a universal retail ERP.

## Included areas
- Shop-owner workspace: dashboard, products/stock, sales/billing, purchases, customers, suppliers, expenses, reports, staff and shop settings.
- Separate Platform Super Admin workspace: sample shop-owner subscription list, plan/status management, sample monthly recurring revenue summary, signup toggle, maintenance-mode toggle and announcement editor.

## Run locally
Open `index.html` in a modern browser.

## Publish with GitHub Pages
1. Create a new GitHub repository (for example `shoppilot-erp`).
2. Upload `index.html`, `.nojekyll`, and this README to the repository root.
3. In the repository, open **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Select the `main` branch and `/ (root)`, then save.
6. Wait for GitHub Pages to publish the site.

## Important production requirements
This is a frontend demo. Records are sample/in-memory data and reset when the page is refreshed. The admin screen is NOT protected authentication. Do not use it for real customers or subscriptions yet.

Before public production use, build a backend with:
- Secure server-side authentication and role-based access (separate platform admin and shop-owner roles).
- Database-backed shops, users, products, invoices and subscription records.
- Server-side plan checks and account suspension/renewal rules.
- A payment provider integration and verified payment webhooks.
- Audit logs, backups, HTTPS, input validation and rate limiting.

Never put admin passwords, payment secrets, API keys or database credentials in this static website or a public GitHub repository.
